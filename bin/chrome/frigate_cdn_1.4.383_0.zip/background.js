//vars
{
    var proxyHosts = {};
    var checkUrls = [];
    var proxyHostsCl = [];
    var lastLoadHosts = {};
    var blHosts = [];

    var timewait = 1E3 * 60 * 30; //min //if proxy on
    var timewait2 = 19E3; // if no need proxy
    var timewait3 = -1;
    var timewaitClSerial = 1E3 * 60 * 60;
    var timewaitUpdateHost = 1E3 * 60 * 9;
    var timewait407 = 1E3 * 60 * 1;
    var rep = {};


    var num_tabs;

    var upd407 = 0;
    var isShowMess = {};
    var presites = null;
    var preurls = null;
    var preproxy = null;
    var ison = true;
    var first = true;
    var attempts = 6;
    var startUrlIndex = 0;
    var endUrlIndex = 1;
    var extArr = ["org", "biz"];
    var prDef = "";
    var prDefCo = "";
    var prDef2 = [
        ["HTTPS uk11.friproxy.biz:443", 'uk'],
        ["HTTPS fr11.friproxy.biz:443", 'fr']
    ];
    var pr2Def2 = [
        "SOCKS5 uk11.friproxy.biz:1080",
        "SOCKS5 fr11.friproxy.biz:1080"
    ]
    var prauth = ls.set('prauth');
    var prauth2 = ls.set('prauth2');

    var pr = "", prco = "", prip, openPr = false, openPrNoNeed, limitText = 'wait';
    var pr2 = '';

    var isProxyHosts = false;
    var isRep = false;

    var news = ls.get('news');
    var updateText = ls.get('updateText');
    var nameTestFile = "/frigate.";
    var noalert = false;
    var noadv = ls.get('noadv');
    var timerUpdateHost = false;
    var md5api = '';
    var uid = ls.get('uidkey');
    var clearcacheis = true;
    var serial = 0;//ls.get('serial');
    var startTime = Date.now();
    var timeClSerial = startTime + timewaitClSerial;
    var detailsApp = chrome.app.getDetails();
    var idContMen = [];
    var iscl = true;
    var proxyOffset = 0;
    var tabUpdateAllArr = {};
    var timerCheckProxy;
    var a = ls.get('a');


//================
//    timewait = 3E4;
//    timewait2 = 20000;
//    timewait3 = -1;
//    timewaitClSerial = 1E3 * 60 * 3;
//    timewaitUpdateHost = 1E3 * 60 * 1;
//    timeClSerial = startTime + timewaitClSerial;
//    isD = true;
//================
}

//console.error = function (par1) {
//    if (isD) {
//        console.log(par1)
//    }
//}

d2('friGate starting...');

//localStorage.clear();

// on or off
{
    if (!uid) {
        localStorage.clear();
        ison = true;
        uid = generatePW();
        ls.set('uidkey', uid, false);
        ls.set("on", true)
    } else if (typeof localStorage["version"] != "undefined") {
        localStorage.clear();
        ison = true;
        ls.set("on", true)
    } else {
        first = false;
        ison = ls.get("on");
    }
}

//d('uid', uid);

var lang = chrome.i18n.getMessage("@@ui_locale");
if (lang != 'ru')
    lang = 'en';

if (first) {
    chrome.tabs.create({"url": "http://fri-gate.org/" + lang + "/chrome" + lang + "/", "active": true});
}

chrome.browserAction.setBadgeBackgroundColor({"color": [55, 169, 224, 90]});
chrome.browserAction.setTitle({title: 'wait'});
chrome.browserAction.setBadgeText({'text': 'wait'});


chrome.webRequest.onBeforeRequest.addListener(reqListenerAll, {urls: ["<all_urls>"], types: ["main_frame"]}, ["blocking"]);


if (updateText)
    updateText = l('messUpdate');

noalertRead();
proxyRead();


loadhosts();

function onProxyError() {

    chrome.proxy.settings.get({incognito: false}, function (details) {
        var err = false;
        //d('details', details);
        if (details && typeof details.levelOfControl != 'undefined' && details.levelOfControl != "controllable_by_this_extension" && details.levelOfControl != "controlled_by_this_extension") {
            err = true;
        }
        if (err && ison) {
            ison = false;
            proxyoff(true, true);
            errIcon();
            chrome.browserAction.setTitle({title: l('messErrOverExtProxy')});
        } else if (!err && !ison) {
            ison = true;
            proxyon();
        }
    });
}


function setUserHostUrl(host, url, list, lid, on) {
    if (on) {
        if (!(url < 0))
            checkUrls.include(host + url);
        proxyHosts[host] = {on: false, d: 0, bl: false, url: url};
        if (list)
            proxyHosts[host].l = list;

        proxyHosts[host].lid = lid;

        if (url == -2)
            proxyHosts[host].ons = true;

        proxyHostsCl.include("*://" + host + "/*");
    } else {
        checkUrls.erase(host + url);
        delete proxyHosts[host];
        proxyHostsCl.erase("*://" + host + "/*");
    }
}

function chNoNeedopenPr() {
//    var lsList = ls.get('list');
//    if (lsList && ((lsListlength = lsList.length) > 0)) {
//        for (var j = 0; j < lsListlength; j++) {
//            if (lsList[j].on && !emptyObject(lsList[j].d))
//                for (var tmp in lsList[j].d)
//                    if (lsList[j].d.hasOwnProperty(tmp)) {
//                        if (lsList[j].d[tmp].on)
//                            return false;
//                    }
//        }
//
//    }
    for (var host in proxyHosts)
        if (proxyHosts.hasOwnProperty(host)) {
            if (typeof proxyHosts[host].l != 'undefined')
                return false;
        }
    return true;
}

function getMessage(request, sender, sendResponse) {
    //d('request.type',request.type);
    if (request) {
        if (request.type == 'getTabId') {
            sendResponse({tabId: sender.tab.id});
        } else if (request.type == 'sovetnik') {
            sendResponse(noadv);
            return true
        } else if (request.type == 'from_s2' && request.tabHost) {
            proxyHosts[request.tabHost].hide = request.value;
            saveHostsToLs();
            //d('request.value',request.value);
        } else if (request.type == "frigate" && request.value) {
            if (request.value == 'anon') {
                a = request.val2 ? 1 : 0;
                //openPr = false;
                //getSitesUrl();
            } else if (request.value == 'noalert') {
                noalertRead();

            } else if (request.value == 'noadv') {
                noadvRead();

            } else if (request.value == "proxy") {
                preproxy = '';
                if (proxyRead() == 'f') {

                    openPrNoNeed = chNoNeedopenPr();

                    if (openPr || openPrNoNeed)
                        setProxy(function () {
                            checkAllTabWhenEnable(false);
                        });
                    else
                        getSitesUrl(false, function () {
                            checkAllTabWhenEnable(false);
                        });
                } else {

                    setProxy($empty);
                }
            } else if (request.value == "getfrlist") {
                sendResponse(lastLoadHosts);
            }
        } else if (request.type == "chproxy" && request.tabHost && request.url && request.tabId) {
            proxyOffset++;
            serial = 0;
            openPr = false;
            getSitesUrl(false, function () {
                tabUpdate(false, request.url, request.tabId);
            });
        } else if (request.type == "frigatetabon" && request.tabHost && request.url && request.tabId) {
            proxyHosts[request.tabHost]['man'] = true;
            setProxy(function () {
                actIcon();
                tabUpdate(false, request.url, request.tabId);
            });

        } else if (request.type == "frigatetaboff" && request.tabHost && request.url && request.tabId) {
            proxyHosts[request.tabHost]['man'] = false;
            setProxy(function () {
                noActIcon();
                tabUpdate(false, request.url, request.tabId);
            });

        } else if (request.type == "frigateisshow" && request.tabId) {
            isShowMess[request.tabId] = true;
        } else if (request.type == "frigatelist") {
            var on = request.value.act == 'onlist';
            if (on || request.value.act == 'offlist') {

                if (request.value.id) {
                    var lsList = ls.get('list');
                    if (lsList && lsList.length > 0) {

                        if (typeof lsList[request.value.id] !== 'undefined') {
                            var siteList = lsList[request.value.id];
                            if (siteList.d.length > 0) {
                                //openPr = chNoNeedopenPr();

                                Object.each(siteList.d, function (val, key) {
                                    if (val.on) {
                                        setUserHostUrl(val.h, val.u, siteList.n, key, on);
                                    }
                                });
                                if (ison)
                                    setOrUpdateHandlers();
                                saveHostsToLs();
                                if (!openPr) {
                                    // теперь стало надо прокси
                                    openPr = 0;
                                    getSitesUrl(false, function () {
                                        checkAllTabWhenEnable(false);
                                    });
                                } else {
                                    setProxy(
                                        function () {
                                            sendResponse(true);
                                        }
                                    );
                                }
                            } else {
                                sendResponse(true);
                            }
                        }
                    }
                }
                return true;
            } else if (request.value.act == 'delurl') {
                //d('delUrl');
                if (request.value.url == -5)
                    return true;
                if (request.value.host && request.value.url) {
                    setUserHostUrl(request.value.host, request.value.url, false, false, false);
                    if (typeof request.value.notApply == 'undefined') {
                        saveHostsToLs();
                        if (ison)
                            setOrUpdateHandlers();
                        if (!openPr) {
                            openPrNoNeed = chNoNeedopenPr();
                            if (openPrNoNeed) {
                                onOffLimit();
                            }
                        }
                        setProxy(
                            function () {
                                sendResponse(true);
                            }
                        );
                    } else {

                        sendResponse(true);
                    }
                } else {
                    sendResponse(true);
                }

                //d(proxyHosts, proxyHosts);
                return true;
            } else if (request.value.act == 'churl') {
                var checkHost = checkHostInProxyHosts('http://' + getClHost(request.value.host));
                if (checkHost.tabHost) {
                    if (typeof proxyHosts[checkHost.tabHost].lid == 'undefined') {
                        sendResponse('friGate');
                    } else {
                        sendResponse(proxyHosts[checkHost.tabHost].lid);

                    }
                } else {
                    sendResponse(false);
                }
            } else if (request.value.act == 'url') {

                setUserHostUrl(request.value.host, request.value.url, request.value.list, request.value.lid, true);
                if (ison)
                    setOrUpdateHandlers();
                saveHostsToLs();

                if (!openPr) {

                    getSitesUrl(false, function () {
                        checkAllTabWhenEnable(request.value.host);
                    });
                    sendResponse(true);
                } else {
                    setProxy(
                        function () {
                            checkAllTabWhenEnable(request.value.host);
                            sendResponse(true);
                        }
                    );
                }
                return true;
            }
            //d(proxyHosts, proxyHosts);
            return true;
        }
    }
}


function noalertRead() {
    var lsnoalert = ls.get('noalert');

    if (lsnoalert !== null) {
        noalert = lsnoalert;
    }
}
function noadvRead() {
    var lsnoadv = ls.get('noadv');

    if (lsnoadv !== null) {
        noadv = lsnoadv;
    }
}

function proxyRead() {
    var lspr = ls.get('pr2');
    if (lspr == null || lspr.length < 1) {
        if (prDef) {
            pr = prDef;
            prco = prDefCo;
        } else {
            var prRand = Math.floor(Math.random() * (prDef2.length));
            pr = prDef2[prRand][0];
            prco = prDef2[prRand][1];
            pr2 = pr2Def2[prRand];
        }
        prip = getprip(pr);
        return 'f';
    } else {
        pr = '';
        pr2 = '';
        lsprL = lspr.length;
        if (lsprL) {
            for (var j = 0; j < lsprL; j++) {
                pr = pr + lspr[j];
                if (j == (lsprL - 1)) {
                    pr = pr + ';';
                }
            }
        }
        prip = '';
        prco = '';
        openPr = true;
        return 'o';
    }
}

function checkHostInProxyHosts(url) {
    var ret = {'tabHost': false, 'tabClHost': '', 'isSheme': false, 'allow': false};
    var urlSplit = url.split(/\/+/g);

    ret['sheme'] = urlSplit[0] + "//";
    ret['host'] = urlSplit[1];

    if (ret.sheme == "http://" || ret.sheme == "https://") {
        ret.isSheme = true;
    }
    if (typeof proxyHosts[ret.host] !== "undefined") {
        ret.tabHost = ret.host;
        ret.tabClHost = ret.host;
    } else {
        var hostSplitDot = ret.host.split(/\./g);
        var hostSplitDotLength = hostSplitDot.length;
        if (hostSplitDotLength > 1) {
            ret.tabClHost = hostSplitDot[hostSplitDotLength - 1];
            for (var i = hostSplitDotLength - 2; i > -1; i--) {
                ret.tabClHost = hostSplitDot[i] + '.' + ret.tabClHost;
                if (typeof proxyHosts['*.' + ret.tabClHost] !== "undefined") {
                    ret.tabHost = '*.' + ret.tabClHost;
                    break;
                }
            }
        }

    }
    if (ret.tabHost) {
        if (openPr || (!openPr && typeof proxyHosts[ret.tabHost].lid == 'undefined')) {
            ret.allow = true;
        }
    }
    return ret;
}

function checkAllTabWhenEnable(host) {
    //d('checkAllTabWhenEnable', '');
    if (ison)
        chrome.tabs.query({}, function (tabs) {
            var objHost;
            var tabslength = tabs.length;
            for (var i = 0; i < tabslength; i++) {
                objHost = checkHostInProxyHosts(tabs[i].url);
                if (objHost.tabHost && (!host || (host && objHost.tabHost == host))) {
                    //d('update', tabs[i].id);
                    try {
                        chrome.tabs.update(tabs[i].id, {url: tabs[i].url}, function () {
                        });
                    } catch (e) {
                    }
                }
            }
        });
}


function tabListener31(tabId, changeInfo, tab) {
    if (typeof changeInfo.url !== "undefined")
        tabListenerAll(changeInfo.url, tabId, true);
    else
        tabListenerAll(tab.url, tabId, true);
}
function tabListener32(info) {
    chrome.tabs.get(info.tabId, function (tab) {
        if (typeof tab.url != 'undefined')
            tabListenerAll(tab.url, info.tabId, false);
    })
}
function tabListenerAll(url, tabId, onlyIco) {
    //d('tabListenerAll ison', ison);
    if (ison) {
        //d('tabListenerAll isProxyHosts', isProxyHosts);
        //d('tabListenerAll url', url);
        if (isProxyHosts && url) {
            var list, hide = false;

            var tmpcheckHost = checkHostInProxyHosts(url);
            //d('tabListenerAll tmpcheckHost', tmpcheckHost);
            if (tmpcheckHost.tabHost && tmpcheckHost.allow) {
                //d('tabListenerAll tabHost', tmpcheckHost.tabHost);
                var tabHost = tmpcheckHost.tabHost;
                tmpcheckHost = null;

                if (onlyIco) {
                    if (typeof isShowMess[tabId] == "undefined") {
                        //d('tabListenerAll showMess', tabId);
                        if (typeof proxyHosts[tabHost].l == 'undefined') {
                            list = '<b>friGate</b>';
                        } else {
                            list = '<b>' + proxyHosts[tabHost].l + '</b>';
                        }
                        if (typeof proxyHosts[tabHost].hide != 'undefined') {
                            hide = proxyHosts[tabHost].hide;
                        }
                        if (proxyHosts[tabHost].man) {
                            showMess(tabId, [l('messProxyOnManually'),
                                l('messProxyIsOff'),
                                l('messFromList') + list], hide, tabHost, url, 1);
                        } else if (proxyHosts[tabHost].ons) {
                            showMess(tabId, [l('messTypeCh3'),
                                '',
                                l('messFromList') + list], hide, tabHost, url, 4);
                        } else if (proxyHosts[tabHost].on) {
                            showMess(tabId, [l('messProxyOn'),
                                '',
                                l('messFromList') + list], hide, tabHost, url, 3);
                        } else {
                            showMess(tabId,
                                [l('messSiteWithoutProxy'),
                                    l('messProxyOff'),
                                    l('messFromList') + list],
                                hide, tabHost, url, 0);
                        }
                        //lastShowMes[tabHost] = Date.now() + timewait3;
                    }

                }
                chrome.tabs.getSelected(null, function (tab) {

                    if (tab.id == tabId)
                        if (proxyHosts[tabHost].on || proxyHosts[tabHost].ons || proxyHosts[tabHost].man) {
                            actIcon(tabId);
                            return true;
                        } else {
                            listIcon();
                            return false;
                        }
                });
            }
        }
        noActIcon();
    }
    else
        disIcon();
}

function reqListenerAll(details) {
    //d('reqListenerAll', details.url);
    if (details.tabId && details.url) {
        tabUpdateAllArr[details.tabId] = details.url;
        //return{redirectUrl: 'wait'};
    }
}

var checkResponseHeaders = function (responseHeaders) {
    var locationKey = 0;

    Array.each(responseHeaders, function (val, key) {
        val.name = val.name.toLowerCase();
        if (val.name == 'location') {
            locationKey = key;
        }

    });
    return locationKey;
}

var reqOnHeadersReceived = function (details) {
    //d('details', details);
    var reg300 = /(3)\d\d/g;
    if (reg300.test(details.statusLine)) {
        //if (details.statusLine == "HTTP/1.1 301 Moved Permanently") {
        //d('reqOnHeadersReceived', details);
        if (details.type == 'xmlhttprequest') {
            if (details.url.indexOf('frigate_404_check') != -1)
                return {cancel: true};

        } else {

            hostObj = checkHostInProxyHosts(details.url);
            if (hostObj.tabHost && !proxyHosts[hostObj.tabHost].on && hostObj.allow) {

                var locationKey = checkResponseHeaders(details.responseHeaders);

                if (locationKey) {
                    toUrl = details.responseHeaders[locationKey].value;
                    //d('toUrl', toUrl);
                    var toUrlAr = toUrl.split(/\/+/g);
                    toUrl = toUrlAr[1];
                    //d('toUrl', toUrl);
                    //d('blHosts', blHosts);
                    blHostslength = blHosts.length
                    if (blHostslength > 0)
                        for (var i = 0; i < blHostslength; i++) {
                            if (toUrl.indexOf(blHosts[i]) != -1) {

                                proxyHosts[hostObj.tabHost].bl = true;
                                proxyHosts[hostObj.tabHost].upd = {};
                                proxyHosts[hostObj.tabHost].upd[details.tabId] = details.url;
                                noSiteRes(hostObj.tabHost, null, details.tabId, details.url, null, null);
                                //return{redirectUrl: 'wait'};
                            }
                        }
                }
            }
        }
    }
    return {cancel: false};
}

function reqListener(details) {
    if (typeof isShowMess[details.tabId] != "undefined")
        delete isShowMess[details.tabId];
    //d('reqListener', details.url);
    //d('details.tabId', details.tabId);
    //d('reqListener == proxyHosts', proxyHosts);
    //d('reqListener == rep', rep);
    if ((isProxyHosts || isRep) && details.url) {
        var url = details.url;
        var tmpcheckHost = checkHostInProxyHosts(url);

        if (tmpcheckHost.isSheme) {
            //d('reqListener', tabHost);
            if (isRep) {

                if (typeof rep[tmpcheckHost.host] != "undefined") {

                    var newUrl = url.replace(tmpcheckHost.host, rep[tmpcheckHost.host]);
                    //d('redirectUrl', newUrl);
                    return{redirectUrl: newUrl};
                }
            }


            if (tmpcheckHost.tabHost && tmpcheckHost.allow && !proxyHosts[tmpcheckHost.tabHost].ons) {
                //tmpLsd('tmpcheckHost.tabHost', tmpcheckHost.tabHost);
                var tabHost = tmpcheckHost.tabHost;
                var tabClHost = tmpcheckHost.tabClHost;
                //d('proxyHosts[tabHost].bl', tabHost);
                if (!proxyHosts[tabHost].bl) {
                    var churl, churl2;
                    //chrome.tabs.executeScript(details.tabId, {file: "js/pre.js", allFrames: false, runAt: 'document_start'});

                    if (proxyHosts[tabHost].d < Date.now()) {
                        proxyHosts[tabHost].bl = true;
                        proxyHosts[tabHost].upd = {};
                        proxyHosts[tabHost].upd[details.tabId] = url;

                        //d('proxyHosts[tabHost].upd1', proxyHosts[tabHost].upd);

                        if (typeof proxyHosts[tabHost].url !== "undefined") {
                            if (proxyHosts[tabHost].url == -1) {
                                var noSiteResfu = function (ret) {

                                    var reg404 = /(4|5)\d\d/g;
                                    if (reg404.test(ret.status)) {
                                        j = true;
                                    } else {
                                        j = false;
                                    }
                                    ret = null;
                                    noSiteRes(tabHost, tabClHost, details.tabId, url, j, 3);
                                };
                                churl = genRandFile(tmpcheckHost.sheme, tabClHost);
                                //d('churl', churl);
                                getUrl3(churl, "get", "", noSiteResfu, noSiteResfu);
                            } else {
                                //
                                proxyHosts[tabHost].testsize = -2;
                                var noSiteResfu = function (ret) {
                                    //d('ret', ret);
                                    var j = {};
                                    if (ret) {
                                        if (typeof ret == 'object') {
                                            //d('ret', ret);
                                            ret = '';
                                        }
                                        //d('-------',ret);
                                        j = h(ret);
                                        //j.s = ret.length;

                                    }
                                    else
                                        j = false;

                                    noSiteRes(tabHost, tabClHost, details.tabId, url, j, 2);
                                };

                                churl = tmpcheckHost.sheme + tabClHost + proxyHosts[tabHost].url;
                                getUrl3(churl, "get", "", noSiteResfu, noSiteResfu);

                                churl2 = genRandFile(tmpcheckHost.sheme, tabClHost);
                                getUrl3(churl2, "get", "", noSiteResfu, noSiteResfu);
                            }
//                        else {
//                            
//                            proxyHosts[tabHost].testsize = -2;
//                            var noSiteResfu = function(ret) {
//                                //d('ret', ret);
//                                var j = {};
//                                if (ret) {
//                                    //d('-------',ret);
//                                    j = h(ret);
//                                    //j.s = ret.length;
//                                }
//                                else
//                                    j = false;
//
//                                noSiteRes(tabHost, tabClHost, details.tabId, url, j, 2);
//                            };
//                            var noSiteResfu2 = function(j) {
//                                //d('noSiteResfu2', j);
//                                noSiteRes(tabHost, tabClHost, details.tabId, url, j, 2);
//                            };
//
//                            churl = tmpcheckHost.sheme + tabClHost + proxyHosts[tabHost].url;
//
//                            encchurl = Base64.encode(XXTEA.encrypt(churl, '1111111111111111'));
//                            //d('urlForGetSize',urlForGetSize);
//                            getUrl(urlForGetSize, "post", "u=" + encodeURIComponent(encchurl), noSiteResfu2, noSiteResfu2, noSiteResfu2);
//                            getUrl3(churl, "get", "", noSiteResfu, noSiteResfu, noSiteResfu);
//                        }
                        } else {
                            var noSiteResfu = function (j) {

                                noSiteRes(tabHost, tabClHost, details.tabId, url, j, false);
                            };
                            churl = tmpcheckHost.sheme + tabClHost + nameTestFile + tabClHost + ".js";
                            getUrl(churl, "get", "", noSiteResfu, noSiteResfu);
                        }


                        //return{cancel: true}
                        //d('WAIT1', '')
                        //return{redirectUrl: 'wait'};
                    } else {
                        //

                        if (!noalert) {
                            //d('reqListener showwait',details.tabId);
                            chrome.tabs.sendMessage(details.tabId, {'type': "showwait"});
                        }
                        return{cancel: false}
                    }
                } else {
                    //return{cancel: true}
                    //d('WAIT2', '')
                    proxyHosts[tabHost].upd[details.tabId] = url;
                    //d('proxyHosts[tabHost].upd2', proxyHosts[tabHost].upd);
                    //return{redirectUrl: 'wait'};
                }
            } else {

                return{cancel: false}
            }
        }
    }
    return{cancel: false}
}

function onAddAuthHeader(details) {
    hostObj = checkHostInProxyHosts(details.url);
    if (hostObj.tabHost && hostObj.allow) {
        if (proxyHosts[hostObj.tabHost].on || proxyHosts[hostObj.tabHost].ons || proxyHosts[hostObj.tabHost].man) {
            //
            if (a) {
                if (prauth2) {
                    details.requestHeaders.push({name: 'Proxy-Authorization', value: prauth2});
                }
            } else {
                if (prauth) {
                    details.requestHeaders.push({name: 'Proxy-Authorization', value: prauth});
                }
            }
        }
    }
    return {requestHeaders: details.requestHeaders};
}

function reqOnResponseStarted(details) {

    if (!noalert)
        if (isProxyHosts && details.url) {

            var tmpcheckHost = checkHostInProxyHosts(details.url);

            if (tmpcheckHost.tabHost && tmpcheckHost.allow) {
                //d('reqOnResponseStarted showwait',details.tabId);
                chrome.tabs.sendMessage(details.tabId, {'type': "showwait"});
            }
            tmpcheckHost = null;
        }

    if (typeof details.statusCode != 'undefined' && details.statusCode == 407) {
        var now = Date.now();
        if (upd407 < now) {
            upd407 = now + timewait407;
            getSitesUrl(false, function () {
                if (details.url && details.tabId)
                    tabUpdate(null, details.url, details.tabId);
            });
        }
        d2(details.statusCode);
        d('url', details.url);
    }

}
function reqOnErrorOccurred(details) {

}


function onoff() {
    //d('onoff', ison);
    //if (!first) {
    if (ison)
        proxyoff();
    else
        proxyon();

//    } else {
//        first = false;
//    }
}

function onOffLimit() {

    //if (!openPr)
    openPrNoNeed = chNoNeedopenPr();

    //d('onOffLimit = openPr', openPr);

    if (openPr || openPrNoNeed) {
        limitText = '';

    } else {
        limitText = 'lim';
        chrome.browserAction.setTitle({title: l('messErrLim')});
    }
    if (ison) {
        chrome.tabs.getSelected(null, function (tab) {
            tabListenerAll(tab.url, tab.id, true);
        });
    }
    //d('onOffLimit = limitText', limitText);
}

function proxyoff(nosave, errpr) {
    //alert('off');
    d2('off');

    if (timerUpdateHost)
        clearInterval(timerUpdateHost);
    timerUpdateHost = false;
    if (!errpr) {
        if (timerCheckProxy)
            clearInterval(timerCheckProxy);
        timerCheckProxy = false;
    }

    presites = null;
    preurls = null;
    preproxy = null;
    openPr = false;
    md5api = false;
//    if (chrome.proxy.onProxyError.hasListener(onProxyError)) {
//        chrome.proxy.onProxyError.removeListener(onProxyError);
//    }

    setOrUpdateHandlers(true);

    setOrUpdateTabHandlers(true);
    disIcon();
    chrome.proxy.settings.clear({scope: "regular"}, function () {
        checkAllTabWhenEnable(false);
        if (!nosave) {
            ison = null;
            ls.set("on", false);
        }
    });

}

function clearcache(t, f) {
    //d('clearcacheis', clearcacheis);
    if (clearcacheis) {
        clearcacheis = false;
        var ago;
        if (t)
            ago = Date.now() - t;
        else
            ago = startTime;

        startTime = Date.now();
        //chrome.webRequest.handlerBehaviorChanged(function() {
        //d('chrome.browsingData',ago);
        try {
            //chrome.browsingData.remove({since: ago}, {"appcache": false, "cache": true, "cookies": false, "downloads": false, "fileSystems": false, "formData": false, "history": false, "indexedDB": false, "localStorage": false, "pluginData": false, "passwords": false, "webSQL": false}, function(){d('===','');f()});
            chrome.browsingData.removeCache({"since": ago}, f);
            //, "originTypes": {"unprotectedWeb": true}}
        } catch (e) {
            if (typeof f == 'function')
                f();
        }
        //});

    }
//chrome.browsingData.removeCache({"since": ago}, f);
}

function offHandlersAll() {
    if (chrome.webRequest.onBeforeRequest.hasListener(reqListenerAll)) {
        chrome.webRequest.onBeforeRequest.removeListener(reqListenerAll);
    }
}

function setOrUpdateHandlers(off) {

    offHandlersAll();

    //d('setOrUpdateHandlers','');

    if (chrome.webRequest.onBeforeRequest.hasListener(reqListener)) {
        chrome.webRequest.onBeforeRequest.removeListener(reqListener);
    }
    if (!off)
        chrome.webRequest.onBeforeRequest.addListener(reqListener, {urls: proxyHostsCl, types: ["main_frame"]}, ["blocking"]);

    if (chrome.webRequest.onHeadersReceived.hasListener(reqOnHeadersReceived)) {
        chrome.webRequest.onHeadersReceived.removeListener(reqOnHeadersReceived);
    }
    if (!off)
        chrome.webRequest.onHeadersReceived.addListener(reqOnHeadersReceived, {urls: proxyHostsCl, types: ["xmlhttprequest", "main_frame"]}, ["blocking", "responseHeaders"]);

    if (chrome.webRequest.onErrorOccurred.hasListener(reqOnErrorOccurred)) {
        chrome.webRequest.onErrorOccurred.removeListener(reqOnErrorOccurred);
    }
    if (!off)
        chrome.webRequest.onErrorOccurred.addListener(reqOnErrorOccurred, {urls: proxyHostsCl, types: ["main_frame"]});

    if (chrome.webRequest.onHeadersReceived.hasListener(reqOnResponseStarted)) {
        chrome.webRequest.onHeadersReceived.removeListener(reqOnResponseStarted);
    }
    if (!off)
        chrome.webRequest.onHeadersReceived.addListener(reqOnResponseStarted, {urls: proxyHostsCl, types: ["main_frame"]});

    if (chrome.webRequest.onResponseStarted.hasListener(reqOnResponseStarted)) {
        chrome.webRequest.onResponseStarted.removeListener(reqOnResponseStarted);
    }
    if (!off)
        chrome.webRequest.onResponseStarted.addListener(reqOnResponseStarted, {urls: proxyHostsCl, types: ["main_frame"]});

    if (chrome.webRequest.onCompleted.hasListener(reqOnResponseStarted)) {
        chrome.webRequest.onCompleted.removeListener(reqOnResponseStarted);
    }
    if (!off)
        chrome.webRequest.onCompleted.addListener(reqOnResponseStarted, {urls: proxyHostsCl, types: ["main_frame"]});

    if (chrome.webRequest.onBeforeSendHeaders.hasListener(onAddAuthHeader)) {
        chrome.webRequest.onBeforeSendHeaders.removeListener(onAddAuthHeader);
    }
    if (!off) {
        chrome.webRequest.onBeforeSendHeaders.addListener(onAddAuthHeader, {urls: ["http://*/*"]}, ["requestHeaders", "blocking"]);
    }
}

function setOrUpdateTabHandlers(off) {

    if (chrome.tabs.onUpdated.hasListener(tabListener31)) {
        chrome.tabs.onUpdated.removeListener(tabListener31);
    }
    if (chrome.tabs.onActivated.hasListener(tabListener32)) {
        chrome.tabs.onActivated.removeListener(tabListener32);
    }
    if (!off) {
        chrome.tabs.onUpdated.addListener(tabListener31);
        chrome.tabs.onActivated.addListener(tabListener32);
    }
}

function proxyon(itIsInit) {
    d2('on');


    chrome.browserAction.setBadgeText({'text': 'wait'});
    limitText = 'wait';
    chrome.proxy.settings.get({'incognito': false}, function (details) {
        //d('details', details);
        //alert('on');

        //d('proxyon', '');
        if (details && typeof details.levelOfControl != 'undefined' && details.levelOfControl != "controllable_by_this_extension" && details.levelOfControl != "controlled_by_this_extension") {
            ison = false;
            chrome.browserAction.setTitle({title: l('messErrOverExtProxy')});
            errIcon();
            return false;
        }

        //if (!chrome.proxy.onProxyError.hasListener(onProxyError))
        //    chrome.proxy.onProxyError.addListener(onProxyError);
        if (!timerCheckProxy)
            timerCheckProxy = setInterval(onProxyError, 700);

        ison = true;

        if (!itIsInit) {
            if (isProxyHosts || isRep) {
                setProxy(function () {
                    setOrUpdateHandlers(0);
                    setOrUpdateTabHandlers(0);
                });
            }
        }

        openPrNoNeed = chNoNeedopenPr();

        getSitesUrl(false, function () {
            checkAllTabWhenEnable(false);
        });
        //if (!itIsInit)
        //    onOffLimit();

        if (!timerUpdateHost)
            timerUpdateHost = setInterval(getSitesUrl, timewaitUpdateHost);

        chrome.tabs.getSelected(null, function (tab) {
            tabListenerAll(tab.url, tab.id, true);
        });

        clearcache(1E3 * 60 * 60 * 24 * 1, function () {

            ls.set("on", true);
            clearcacheis = true;
        });

    });
}
function actIcon() {
    if (a) {
        chrome.browserAction.setIcon({path: "im/38aan.png"});
        chrome.browserAction.setTitle({title: l('messProxyOnAn')});
    } else {
        chrome.browserAction.setIcon({path: "im/38a.png"});
        chrome.browserAction.setTitle({title: l('messProxyOn')});
    }
    //d('limitText', limitText);
    chrome.browserAction.setBadgeText({'text': limitText});
}
function listIcon() {
    chrome.browserAction.setTitle({title: l('browser_action_title')});
    if (a)
        chrome.browserAction.setIcon({path: "im/38lan.png"});
    else
        chrome.browserAction.setIcon({path: "im/38l.png"});
    chrome.browserAction.setBadgeText({'text': limitText});
}
function noActIcon() {
    chrome.browserAction.setTitle({title: l('browser_action_title')});
    if (a)
        chrome.browserAction.setIcon({path: "im/38an.png"});
    else
        chrome.browserAction.setIcon({path: "im/38.png"});
    chrome.browserAction.setBadgeText({'text': limitText});
}
function disIcon() {
    chrome.browserAction.setIcon({path: "im/38g.png"});
    chrome.browserAction.setBadgeText({'text': 'off'});
    chrome.browserAction.setTitle({title: l('browser_action_title')});
}
function errIcon() {
    chrome.browserAction.setIcon({path: "im/38g.png"});
    chrome.browserAction.setTitle({title: l('messErrOverExtProxy')});
    chrome.browserAction.setBadgeText({'text': 'err'});
}


function showMess(tabId, mess, hide, tabHost, url, isonepage) {
    //d('showMess',url);

    if (!noalert)
        chrome.tabs.query({url: url}, function (tabs) {
            var tabsId = tabs.map(function (item, index) {
                return item.id;
            });
            //d('tabsId',tabsId);
            //d('tabId',tabId);
            if (tabsId.contains(tabId)) {
                //d('showMess',tabId);
                chrome.tabs.sendMessage(tabId, {'type': "s2", 'tabHost': tabHost, 'tabUrl': url, 'hide': hide, 'tabId': tabId, u: updateText, n: news, 'pr': [prip + ' ' + l('messChange'), prco], 'value': {'dop': mess, 'isonepage': isonepage}});

            }
        });
    return;
}

function tabUpdateAll() {
    if (!emptyObject(tabUpdateAllArr)) {
        //d('tabUpdateAll', tabUpdateAllArr);
        chrome.tabs.query({}, function (tabs) {
            var ntid;
            var tabsId = tabs.map(function (item) {
                return item.id;
            });
            for (var tid in tabUpdateAllArr)
                if (tabUpdateAllArr.hasOwnProperty(tid)) {
                    ntid = parseInt(tid);
                    if (tabsId.contains(ntid)) {
                        //d(tabUpdateAllArr[tid],tid);
                        try {
                            chrome.tabs.update(ntid, {url: tabUpdateAllArr[tid]}, function () {
                            });
                        } catch (e) {
                        }
                    }
                }
            tabUpdateAllArr = {};
        });

    }
}
function tabUpdate(host, url, tabId) {
    //d('tabUpdate host', host);
    //clearcache(0, function() {
    //d('tabUpdate host', tabId);
    //d('tabUpdate url', url);
    if (host && host.length > 0) {
        //d('tabUpdate proxyHosts[host].bl = false', '');


        proxyHosts[host].bl = false;


        if (typeof proxyHosts[host].upd == 'object' &&
            !emptyObject(proxyHosts[host].upd) > 0) {
            chrome.tabs.query({}, function (tabs) {
                var tabsId = tabs.map(function (item, index) {
                    return item.id;
                });

                //proxyHosts[host].bl = false;
                //d('proxyHosts[host].upd', proxyHosts[host].upd);

                if (typeof proxyHosts[host].upd == 'object')
                    Object.each(proxyHosts[host].upd, function (url2, tabId2) {
                        tabId2 = parseInt(tabId2);
                        if (tabsId.contains(tabId2))
                            try {
                                chrome.tabs.update(tabId2, {url: url2}, function () {
                                });
                            } catch (e) {
                            }
                    });
                delete proxyHosts[host].upd;
            });
        } else {
            delete proxyHosts[host].upd;
        }
    } else {
        try {
            chrome.tabs.update(tabId, {url: url}, $empty);
        } catch (e) {
        }
    }
    clearcacheis = true;
    //});
}

function noSiteRes(host, resHost, tabId, url, j, type) {
    var noSetProxy = false;
    //d('noSiteRes', j);
    //d('type', type);
    if ((type == 2 || type == 7) && (typeof j.s !== "undefined")) {
        //d('j', j);
        if (proxyHosts[host].testsize == -2) {

            proxyHosts[host].testsize = j["s"];
            proxyHosts[host].testhash = j["h"];
            return true;
        } else {
            if (type == 7) {
                if (checkN(proxyHosts[host].testsize, j["s"], 15)) {
                    if (compareH(proxyHosts[host], j["h"]) < 0.15) {
                        noSetProxy = true;
                    }
                }
            } else if (type == 2) {
                noSetProxy = true;
                if (checkN(proxyHosts[host].testsize, j["s"], 15)) {
                    if (compareH(proxyHosts[host], j["h"]) < 0.15) {
                        noSetProxy = false;
                    }
                }
            }
            delete proxyHosts[host].testsize;
            delete proxyHosts[host].testhash;
        }
    }
    //d('proxyHosts[host].testsize', proxyHosts[host].testsize);

    if ((type == 3 && j) || (type == 2 && noSetProxy) || (!type && j && typeof j.res !== "undefined" && j["res"] == resHost)) {
        //d('is file ', j);
        d2(host + ' - available');
        //delete blReq[proxyHosts[host].reqId];
        preOn = proxyHosts[host].on;

        //proxyHosts[host] = {on: false, d: Date.now() + timewait2, bl: false};
        proxyHosts[host].on = false;
        proxyHosts[host].d = Date.now() + timewait2;

        //ls.set('hosts', proxyHosts, true);
        //saveHostsToLs();

        if (preOn) {
            //lastShowMes[host] = Date.now() + timewait2;

            setProxy(function () {
                noActIcon();
                tabUpdate(host, url, tabId);
            });
        } else {
            tabUpdate(host, url, tabId);
        }
    } else {
        preOn = proxyHosts[host].on;

        d2(host + ' - not available');

        //proxyHosts[host] = {on: true, d: Date.now() + timewait, bl: false, reqId: proxyHosts[host].reqId};

        proxyHosts[host].on = true;
        proxyHosts[host].d = Date.now() + timewait;


        if (!preOn) {
            setProxy(function () {
                actIcon();
                tabUpdate(host, url, tabId);
            });
        } else {
            tabUpdate(host, url, tabId);
        }
    }
}

var ind = startUrlIndex - 1;
var indExt = 0;
function genNewUrl() {
    var inds = '';
    ind++;

    if (ind > endUrlIndex) {
        ind = startUrlIndex;
        indExt++;
        if (indExt > (extArr.length - 1))
            indExt = 0;
    }

    if (ind != endUrlIndex)
        inds = ind;

    ext = extArr[indExt];

    return "http://api.fri-gate" + inds + "." + ext + apiPath + apiFile;
}

function reGet(resfu) {
    //d('attempts', attempts);
    //return true;
    attempts = attempts - 1;
    if (attempts > 0) {
        getSitesUrl(genNewUrl(), resfu);
    } else {
        if (attempts > -1) {
            getSitesUrl(false, resfu);
        } else {
            attempts = 6;
            ind = startUrlIndex - 1;
            indExt = 0;

            if (proxyHostsCl.length < 1) {
                proxyoff();
            } else
                onOffLimit();
            return true;
        }
    }
}

function saveHostsToLs() {
    //console.assert(false, "stack");
    var toLs = {};
    if (!emptyObject(proxyHosts)) {
        var value;
        for (var host in proxyHosts)
            if (proxyHosts.hasOwnProperty(host)) {
                value = proxyHosts[host];
                if (typeof value['ons'] !== "undefined" && value['ons']) {
                    toLs[host] = {'ons': true};
                } else {
                    toLs[host] = {};
                }
                if (typeof value['url'] !== "undefined" && value['url']) {
                    toLs[host].url = value['url'];
                }
                if (typeof value['l'] !== "undefined" && value['l']) {

                    toLs[host].l = value['l'];
                }
                if (typeof value['lid'] !== "undefined" && value['lid']) {

                    toLs[host].lid = value['lid'];
                }

                if (typeof value['hide'] !== "undefined" && value['hide']) {
                    toLs[host].hide = true
                }

            }
        //d('saveHostsToLs', toLs);
    }
    ls.set('hosts', toLs, uid);
}

function savenewhosts(newhosts, delhost) {
    //var isChange = false;
    var add = 0, del = 0;

    if (delhost && !emptyObject(delhost) && !emptyObject(proxyHosts))
        Array.each(delhost, function (host, ind) {
            if (typeof proxyHosts[host] != "undefined" && typeof proxyHosts[host]['lid'] == "undefined") {
                delete proxyHosts[host];
                proxyHostsCl.erase("*://" + host + "/*");
                del++;
            }

        });

    if (!proxyHosts)
        proxyHosts = {};
    Object.each(newhosts, function (value) {
        host = value.h
        if (typeof proxyHosts[host] == "undefined") {
            proxyHosts[host] = {on: false, d: 0, bl: false};
            if (typeof value.ons !== "undefined" && value.ons) {
                proxyHosts[host]['ons'] = true;
            } else {
                proxyHosts[host]['ons'] = false;
            }
            proxyHostsCl.include("*://" + host + "/*");
            isChange = true;
            isProxyHosts = true;
            add++;
        }
    });

    if (add || del) {
        d2('save to friGate host. add:' + add + ', del:' + del);
        saveHostsToLs();
        return true;
    } else
        return false;
}


function loadhosts() {

    var proxyHostsLength = 0;
    proxyHosts = {};
    proxyHostsCl = [];
    checkUrls = [];

    var tmpLs = ls.get('hosts', uid);
    if (!emptyObject(tmpLs)) {

        for (var host in tmpLs)
            if (tmpLs.hasOwnProperty(host)) {
                var value = tmpLs[host];
                proxyHosts[host] = {on: false, d: 0, bl: false, ons: false};
                proxyHostsLength++;
                if (typeof value['ons'] !== "undefined" && value['ons']) {
                    proxyHosts[host]['ons'] = true;
                }
                if (typeof value['l'] !== "undefined" && value['l']) {

                    proxyHosts[host]['l'] = value['l'];
                }
                if (typeof value['lid'] !== "undefined" && value['lid']) {

                    proxyHosts[host]['lid'] = value['lid'];
                }
                if (typeof value['url'] !== "undefined" && value['url']) {
                    proxyHosts[host]['url'] = value.url;
                    if (!(value.url < 0))
                        checkUrls.push(host + value.url);
                }

                if (typeof value['hide'] !== "undefined" && value['hide']) {
                    proxyHosts[host]['hide'] = true;
                }

                proxyHostsCl.push("*://" + host + "/*");
                isProxyHosts = true;
            }

    }

    var tmprep = ls.get('redir', uid);

    if (tmprep && typeof tmprep == 'object') {

        for (var host in tmprep)
            if (tmprep.hasOwnProperty(host)) {
                proxyHostsCl.include("*://" + host + "/*");
            }

        rep = tmprep;
        isRep = true;
    }

    //d('proxyHostsCl',proxyHostsCl);
    //d('rep',rep);

    if (proxyHostsCl.length < 1) {
        serial = 0;
    }

    d2('loading from localStorage ' + proxyHostsLength + ' hosts');
}


function setProxy(endfunction) {
    var sites = "";
    var urls = "[]";
    var i = false;
    var j = 0;
    var pHosts = [];

    if (ison) {
        d('proxyHosts', proxyHosts);
        for (var host in proxyHosts)
            if (proxyHosts.hasOwnProperty(host)) {
                var value = proxyHosts[host];
                if (openPr || (!openPr && typeof proxyHosts[host].lid == 'undefined'))
                    if (value.on || value.ons || value.man) {
                        i = true;
                        pHosts.push(host);
                    }
            }

        sites = JSON.stringify(pHosts);
        var md5sites = md5(sites);

        j = checkUrls.length;
        if (j > 0)
            urls = JSON.stringify(checkUrls);

        var md5url = md5(urls);

        //d('setProxy', proxyHosts);
        //pr = "PROXY de10.fri-gate.org:8000"
        //pr = "HTTPS ru101.proxy-chrome.com:443"
        //pr = "SOCKS5 api2.fri-gate.org:8000"

        if (presites != md5sites || preurls != md5url || preproxy != pr) {

            presites = md5sites;
            preurls = md5url;
            preproxy = pr;
            //d('setProxy2',i+j);
            if (i || j > 0) {
                //d('setProxy3', '');

                var httpproxy = pr;
                var httpsproxy = pr2;
                if (!httpsproxy) {
                    httpsproxy = "DIRECT";
                }

                postclearproxy = function () {
                    var scr = "function FindProxyForURL(url, host) {" +
                        "var schema=url.substring(0,5); " +
                        "if ( schema!='https' && schema!='http:' ) return 'DIRECT'; " +
                        "if ( shExpMatch( url,'*/aj/frigate/api/+" + apiFile + "*' ) ) return 'DIRECT'; " +
                        "if (shExpMatch( url,\"*" + nameTestFile + "\" + host + \".js*\") ) return 'DIRECT'; " +
                        "if (shExpMatch( url,'*/frigate_404_check_*.png*') ) return 'DIRECT'; " +
                        "var urls = " + urls + "; " +
                        "var url2=url.substring(url.indexOf('//')+2);" +
                        "if ( urls.indexOf(url2)!=-1 )" +
                        " return 'DIRECT';" +
                        "var sites = " + sites + "; " +
                        "var i; var is = false;" +
                        "while (i = sites.shift()) { " +
                        "if (i == host) { is = true; break;} " +
                        "if ( i[0] == '*') { " +
                        "var lenHost = -1*(i.length-2); " +
                        "if (i.substr(lenHost) == host.substr(lenHost)) { is = true; break; } " +
                        "}} " +
                        "if (is) {" +
                        "if ( schema=='http:' ) " +
                        "return '" + httpproxy + "'; else " +
                        "return '" + httpsproxy + "';" +
                        "} " +
                        "return 'DIRECT';" + "}";

                    //d('scr proxy', scr);
                    //d2('set proxy(' + pr + ') script, affects ' + i + ' sites');
                    var config = {mode: "pac_script", pacScript: {data: scr}};
                    try {
                        chrome.proxy.settings.set({value: config,
                            scope: "regular"}, endfunction);
                    } catch (e) {
                        endfunction();
                    }
                };
            } else {
                postclearproxy = endfunction;
            }
            try {
                chrome.proxy.settings.clear({scope: "regular"}, postclearproxy);
            } catch (e) {
                postclearproxy();
            }
            return true;
        }
    }

    if (typeof endfunction == 'function')
        endfunction();
}


function getSitesUrl(urlGet, resfu) {

    if (!openPr) {
        chrome.browserAction.setTitle({title: 'wait'});
    }

    var now = Date.now();

    if (timeClSerial < now) {
        serial = 0;
        timeClSerial = now + timewaitClSerial;

    }
    if (!urlGet) {
        urlGet = urlForGetUrls;
    }
    //d('url', urlGet);
    getUrl3(urlGet, "post", 'k=' + uid + '&s=' + serial + '&po=' + proxyOffset + '&a=' + (a ? 1 : 0) + '&v=1435' + '&op=' + (openPr ? 1 : 0), function (error) {
        //d('err1', '');
        reGet(resfu)
    }, function (enc) {
        //d('enc', enc);
        if (enc) {
            if (enc != 'noUpdate') {
                //d('ok', '');
                var tmpMd5api = md5(enc),
                    isnewhosts = false,
                    isnewpr = false,
                    isnewver = false;

                if (tmpMd5api != md5api) {
                    //d('enc', enc);
                    //d('decr', XXTEA.decrypt(Base64.decode(enc), uid));
                    try {
                        var j = JSON.decode(XXTEA.decrypt(Base64.decode(enc), uid));
                    } catch (e) {
                    }
                    enc = null;
                    //d('j', j);
                    if (j != undefined && typeof j == 'object' && j.serial) {

                        md5api = tmpMd5api;
                        serial = j.serial;

                        if (j.r && Object.getLength(j.r) > 0) {
                            isRep = true;
                            var newrep = {};
                            Array.each(j.r, function (value, key) {
                                newrep[value.f] = value.t;
                                proxyHostsCl.include("*://" + value.f + "/*");
                            });
                            rep = newrep;
                            //d('rep!!',rep);
                            ls.set('redir', rep, uid);
                        }
                        if (j.ip) {
                            d2('you IP: ' + j.ip);
                        }
                        if (j.prauth) {
                            prauth = j.prauth;
                            ls.set('prauth', prauth, false);
                            //d2('get proxy: ' + prauth);
                        }
                        if (j.prauth2) {
                            prauth2 = j.prauth2;
                            ls.set('prauth2', prauth2, false);
                        }
                        if (j.pr) {
                            prDef = j.pr;
                            var lspr = ls.get('pr2');
                            if (!lspr || lspr.length < 1) {
                                if (prDef != pr) {
                                    prDefCo = j.prco;
                                    //d2('get proxy: ' + prDef + ' ' + prDefCo);
                                    pr = prDef;
                                    prco = prDefCo;
                                    prip = getprip(pr);

                                    if (j.pr2) {
                                        pr2 = j.pr2;
                                    }

                                    isnewpr = true;
                                }
                            } else {
                                d2('use own proxy');
                            }
                        }
                        if (j.api) {
                            apiSizeHost = j.api;
                            urlForGetSize = apiSizeHost + apiPath + apiSizeFile;
                        }
                        if (j.blHosts && j.blHosts.length > 0) {
                            blHosts = j.blHosts;
                        }
                        if (j.proxyHosts) {
                            lastLoadHosts = j.proxyHosts;
                            d2('loading from web: ' + j.proxyHosts.length + ' hosts');
                            isnewhosts = savenewhosts(j.proxyHosts, j.delhost);
                        }
                        if (j.err === 0) {
                            //if (openPrNoNeed)
                            isnewpr = true;
                            openPr = true;
                        }
                        onOffLimit();
                        if (j.news) {
                            news = j.news;
                            ls.set('news', j.news);
                        }
                        if (j.ver) {

                            var verAppArr = detailsApp.version.split(/\./g);
                            var verArr = j.ver.split(/\./g);
                            Array.each(verArr, function (val, key) {
                                if (verAppArr[key].toInt() < val.toInt()) {
                                    isnewver = true;
                                }
                            });

                            if (isnewver) {
                                updateText = l('messUpdate');
                                ls.set('updateText', true);
                            } else {
                                updateText = '';
                                ls.set('updateText', false);
                            }
                        }
                        if (isnewhosts || isnewpr) {
                            if (isnewhosts && ison) {
                                setOrUpdateHandlers();
                                setOrUpdateTabHandlers();
                            }
                            setProxy(resfu);
                        }
                    } else {
                        reGet(resfu);
                        d2('error load');
                    }
                } else
                    onOffLimit();
            } else
                onOffLimit();
        } else {
            reGet(resfu);
            d2('error load');
        }
    });
}


chrome.proxy.settings.get({'incognito': false}, function (details) {
        //d('details', details);

        if (details && typeof details.levelOfControl != 'undefined' && details.levelOfControl != "controllable_by_this_extension" && details.levelOfControl != "controlled_by_this_extension") {
            ison = false;

            errIcon();
        }

        if (ison && proxyHostsCl.length > 0) {
            noActIcon();
            //setProxy(function() {

            if (isProxyHosts || isRep) {
                setOrUpdateHandlers();
            } else {
                offHandlersAll();
            }
            tabUpdateAll();
            setOrUpdateTabHandlers(0);
            //});
        } else {
            offHandlersAll();
            tabUpdateAll();
            disIcon();
        }


        onmootools = function () {
            isMooTools = false;

            chrome[runtimeOrExtension].onMessage.addListener(getMessage);

            chrome.tabs.onRemoved.addListener(function () {
                chrome.tabs.query({}, function (tabs) {
                    if (!tabs.length && iscl) {
                        iscl = false;
                        proxyoff(true);
                        function unsleep() {
                            if (!iscl) {
                                iscl = true;
                                proxyon();
                                if (chrome.tabs.onCreated.hasListener(unsleep))
                                    chrome.tabs.onCreated.removeListener(unsleep);
                            }
                        }

                        if (!chrome.tabs.onCreated.hasListener(unsleep))
                            chrome.tabs.onCreated.addListener(unsleep);
                    }
                });
            });

            if (ison)
                proxyon(true);
            else if (first)
                getSitesUrl();


            chrome.browserAction.onClicked.addListener(function () {
                onoff();
            });

            //context menu set listener
//        {
//            idContMen[0] = chrome.contextMenus.create({"title": l("messCmTitleAdd"), "contexts": ["page", "link"],
//                "onclick": $empty});
//            idContMen[1] = chrome.contextMenus.create({"title": l("messCmTitleAddGl"), "contexts": ["page", "link"],
//                "onclick": $empty});
//        }
        }

        if (typeof isMooTools !== 'undefined' && isMooTools)
            onmootools();

    }
);

